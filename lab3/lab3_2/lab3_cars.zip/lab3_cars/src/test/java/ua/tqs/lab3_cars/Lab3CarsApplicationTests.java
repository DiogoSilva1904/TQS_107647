package ua.tqs.lab3_cars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab3CarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
