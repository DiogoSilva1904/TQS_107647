package ua.tqs.lab3_cars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3CarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab3CarsApplication.class, args);
	}

}
